﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WCF.Web
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码、svc 和配置文件中的类名“DBService”。
    // 注意: 为了启动 WCF 测试客户端以测试此服务，请在解决方案资源管理器中选择 DBService.svc 或 DBService.svc.cs，然后开始调试。
    public class DBService : IDBService
    {
        private SqlConnection pSqlConn = null;
        private string sSqlConnString = "Data Source=D405-8;Initial Catalog=yll;Integrated Security=True";    //
        public void DoWork()
        {
        }
        public bool CheckUser(string sUser, string sPsd)
        {
            try
            {
                //连接数据库
                if (CheckSQLConn())
                {
                    string sql = "select * from dbo.Table_info where userName='{0}' and userPsd='{1}'";   ////
                    sql = String.Format(sql, sUser, sPsd);
                    // 查询数据库里面的记录
                    SqlDataAdapter pSQLDataAdapter = new SqlDataAdapter(sql, pSqlConn);
                    DataSet pDataSet = new DataSet();

                    pSQLDataAdapter.Fill(pDataSet);

                    int ResultCount = pDataSet.Tables[0].Rows.Count;
                    //判断该记录是否存在
                    if (ResultCount > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                return false;
            }
        }





              private bool CheckSQLConn()
        {
            try
            {
                //判断连接是否存在
                if (pSqlConn == null)
                {
                    pSqlConn = new SqlConnection();
                    pSqlConn.ConnectionString = sSqlConnString;
                }
                //判断连接有没有开启
                if (pSqlConn.State != ConnectionState.Open)
                {
                    pSqlConn.Open();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }



              public bool creatUser(string suser, string spsd)
              {
                  try
                       {
                pSqlConn = new SqlConnection(sSqlConnString);
                pSqlConn.Open();
                SqlCommand sq = new SqlCommand();
                sq.Connection = pSqlConn;
                sq.CommandType = CommandType.Text;
                sq.CommandText = string.Format("insert into Table_info([userName],[userPsd]) values ('" + suser + "','" + spsd + "')");
                sq.ExecuteNonQuery();
                pSqlConn.Close();
                return true;
                  }
            catch
            {
                return false;

 
            }
        }
 }
        
    
}
