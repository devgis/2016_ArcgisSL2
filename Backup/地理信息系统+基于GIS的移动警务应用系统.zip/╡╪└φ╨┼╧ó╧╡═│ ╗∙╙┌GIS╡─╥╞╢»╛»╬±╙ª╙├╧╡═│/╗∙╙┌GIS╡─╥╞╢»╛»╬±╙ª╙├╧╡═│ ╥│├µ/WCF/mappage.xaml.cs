﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using ESRI.ArcGIS.Client;                          ////
using ESRI.ArcGIS.Client.Symbols;
using ESRI.ArcGIS.Client.Tasks;

namespace WCF
{
    public partial class mappage : Page
    {
        ///渲染

        public mappage()
        {
            InitializeComponent();           
        }

        // 当用户导航到此页面时执行。
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        ///书签
        private void btn_bookmark_Click_1(object sender, RoutedEventArgs e)
        {
            if (this.MyBookMark.Visibility == Visibility.Visible)
            {
                this.MyBookMark.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.MyBookMark.Visibility = Visibility.Visible;
            }
        }


        ///鹰眼
       
        private void btn_overview_Click_1(object sender, RoutedEventArgs e)
        {

            if (this.MyOverviewMap.Visibility == Visibility.Visible)
            {
                this.MyOverviewMap.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.MyOverviewMap.Visibility = Visibility.Visible;
            }
        }


        ///导航条
        private void btn_Navigation_Click_1(object sender, RoutedEventArgs e)
        {

            if (this.MyNavigation.Visibility == Visibility.Visible)
            {
                this.MyNavigation.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.MyNavigation.Visibility = Visibility.Visible;
            }
        }

        ///比例尺
        private void btn_scale_Click_1(object sender, RoutedEventArgs e)
        {
            if (this.MyScaleLine.Visibility == Visibility.Visible)
            {
                this.MyScaleLine.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.MyScaleLine.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// 放大镜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void btn_MagnifyingGlass_Click_1(object sender, RoutedEventArgs e)
        //{
        //    if (this.MyMagnifyingGlass.Visibility == Visibility.Visible)
        //    {
        //        this.MyMagnifyingGlass.Visibility = Visibility.Collapsed;
        //    }
        //    else
        //    {
        //        this.MyMagnifyingGlass.Visibility = Visibility.Visible;
        //    }
        //}
        
        ///渲染
        private void btn_render_Click_1(object sender, RoutedEventArgs e)
        {

            this.Content = new render();
        }


        ///查询

        private void btn_query_Click_1(object sender, RoutedEventArgs e)
        {
            this.Content = new query();
        }

        /// <summary>
        /// 最短路径
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_route_Click_1(object sender, RoutedEventArgs e)
        {
            this.Content = new Route();
        }

        

       


     

    }
}
