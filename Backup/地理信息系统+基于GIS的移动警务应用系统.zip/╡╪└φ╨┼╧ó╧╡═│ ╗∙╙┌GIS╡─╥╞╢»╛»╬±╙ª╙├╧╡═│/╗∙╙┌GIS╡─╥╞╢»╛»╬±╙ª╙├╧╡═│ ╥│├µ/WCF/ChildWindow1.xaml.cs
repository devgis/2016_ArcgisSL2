﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WCF.DBServerSR;                                       /////


namespace WCF
{
    public partial class ChildWindow1 : ChildWindow
    {
        public ChildWindow1()
        {
            InitializeComponent();
        }



        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            string sUserName = UserName.Text.Trim();
            string sUserPsd = UserPsd.Text.Trim();
            DBServiceClient zDBServiceClient = new DBServiceClient();
            zDBServiceClient.creatUserAsync(UserName.Text, UserPsd.Text);
            zDBServiceClient.creatUserCompleted +=zDBServiceClient_creatUserCompleted;     ///  更新DBS
            //this.DialogResult = true;
        }


        /// <summary>
        ///加等于后，从新生成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void zDBServiceClient_creatUserCompleted(object sender, creatUserCompletedEventArgs e)
        {
            try
            {
                if (e.Result)
                {
                    MessageBox.Show("注册成功");
                }
                else
                {
                    MessageBox.Show("用户已存在");
                }
            }
            catch
            {
                MessageBox.Show("网络无法访问！");
            }
        }
   
     

      
        
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

