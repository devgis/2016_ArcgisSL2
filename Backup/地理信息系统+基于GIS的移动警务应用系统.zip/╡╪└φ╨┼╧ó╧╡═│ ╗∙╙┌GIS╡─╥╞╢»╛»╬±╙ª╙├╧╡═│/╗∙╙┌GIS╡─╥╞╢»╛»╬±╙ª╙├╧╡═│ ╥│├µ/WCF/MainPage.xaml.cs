﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WCF.DBServerSR;                          

namespace WCF
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Login_Click_1(object sender, RoutedEventArgs e)
        {
            string sUserName = UserName.Text.Trim();
            string sUserPsd = UserPsd.Text.Trim();
            DBServiceClient pDBServiceClient = new DBServiceClient();
            pDBServiceClient.CheckUserAsync(sUserName, sUserPsd);
            pDBServiceClient.CheckUserCompleted += pDBServiceClient_CheckUserCompleted;


 
        }

        void pDBServiceClient_CheckUserCompleted(object sender, CheckUserCompletedEventArgs e)
        {
            try
            {
                if (e.Result)
                {
                    this.Content = new mappage();                                                          ////
                }
                else
                {
                    MessageBox.Show("用户名或密码不正确");
                }
            }
            catch
            {
                MessageBox.Show("网络无法访问！");
            }

        }



        private void register_Click_1(object sender, RoutedEventArgs e)
        {
            ChildWindow1 zc = new ChildWindow1();                          
            zc.Show();                                              
        }
    } 
}
